/*
  Warnings:

  - You are about to drop the column `features` on the `programs` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `programs` DROP COLUMN `features`;
