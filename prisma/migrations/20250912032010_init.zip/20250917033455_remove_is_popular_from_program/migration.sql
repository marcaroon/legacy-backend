/*
  Warnings:

  - You are about to drop the column `is_popular` on the `programs` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `programs` DROP COLUMN `is_popular`;
