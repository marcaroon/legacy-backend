-- AlterTable
ALTER TABLE `participants` ADD COLUMN `city` VARCHAR(191) NULL;
