// generate-signature.js
const crypto = require("crypto");

const order_id = "ORDER-17-1757583142456"; // sama persis dengan order_id yang dikirim ke Midtrans
const status_code = "200"; 
const gross_amount = "12250000";
const serverKey = "Mid-server-PnTO8Rw7Vb-n4JlFlfquhspj"; 

// Concatenate sesuai dokumentasi Midtrans
const input = order_id + status_code + gross_amount + serverKey;

// Generate SHA512
const signature = crypto.createHash("sha512").update(input).digest("hex");